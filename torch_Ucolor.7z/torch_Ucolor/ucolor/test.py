from main import En_De
import torch
import cv2,datetime,os
import argparse
from tqdm import tqdm
from torchvision import transforms
import numpy as np
from os.path import join

satellite = 'Ucolor'
epoch = '100'

def tensor2img(one_tensor):# [b,c,h,w] [-1,1]
    tensor = one_tensor.squeeze(0) #[c,h,w] [0,1]
    tensor = tensor * 255  # [c,h,w] [0,255]
    tensor_cpu = tensor.cpu()
    img = np.array(tensor_cpu,dtype=np.uint8)
    img = np.transpose(img,(1,2,0))
    return img
def img2tensor(np_img):# [h,w,c]
    tensor = get_transforms()(np_img).cuda() # [c,h,w] [-1,1]
    tensor = tensor.unsqueeze(0) # [b,c,h,w] [-1,1]
    return tensor

def get_transforms():
    transform = transforms.Compose([
        transforms.ToTensor(),# H,W,C -> C,H,W && [0,255] -> [0,1]
        # transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5)) #[0,1] -> [-1,1]
    ])
    return transform
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
parser = argparse.ArgumentParser()
parser.add_argument('--img_folder',type=str,default='./input_90/',help='input image path')
parser.add_argument('--img_depth',type=str,default='./gdcp_90/',help='input depth image path')
parser.add_argument('--output_folder',type=str,default='./wo_output/RL100',help='output folder')
args = parser.parse_args()

if __name__ == "__main__":
    net = En_De().to(device)
    with torch.no_grad():
        checkpoint_model = join('./wo_model/',
                            '{}-model-epochs{}.pth'.format(satellite, epoch))
        checkpoint = torch.load(checkpoint_model, map_location='cpu')
        net.load_state_dict(checkpoint['model'])
        img_folder = args.img_folder
        img_depth = args.img_depth
        pbar = tqdm(os.listdir(img_folder))
        for depth_name in os.listdir(img_depth):
            img_path_depth = os.path.join(img_depth, depth_name)
        for img_name in os.listdir(img_folder):
            img_path_raw = os.path.join(img_folder,img_name)
            img_raw = cv2.cvtColor(cv2.imread(img_path_raw), cv2.COLOR_BGR2RGB)
            img_depth = cv2.imread(img_path_depth,0)
            img_raw = cv2.resize(img_raw,(200,200))
            img_depth = cv2.resize(img_depth, (200, 200))
            img_raw_tensor = img2tensor(img_raw)
            img_depth_tensor = img2tensor(img_depth)
            output_tensor = net.forward(img_raw_tensor,img_depth_tensor)
            output_img = tensor2img(output_tensor)
            save_folder = args.output_folder
            if not os.path.exists(save_folder):
                os.makedirs(save_folder)
            save_path = os.path.join(save_folder,img_name)
            # cv2.imwrite(save_path, output_img)
            cv2.imwrite(save_path,cv2.cvtColor(output_img,cv2.COLOR_RGB2BGR))
            pbar.update(1)