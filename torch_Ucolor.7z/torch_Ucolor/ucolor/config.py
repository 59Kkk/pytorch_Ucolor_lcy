from os.path import join

class FLAGES(object):

    lr=1e-4
    decay_rate=0.99
    decay_step=10000
    num_workers=0
    test_batch_size=1
    trainA_path="./input_train/"
    trainB_path="./depth_train/"
    trainC_path="./gt_train/"
    model_dir = './Rlablemodel/'
    backup_model_dir = join(model_dir)



